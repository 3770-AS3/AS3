﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class putScript : MonoBehaviour
{
    public GameObject[] enemys;//需要添加脚本的物体的数组
    public BALL wander;//SteeringForWander是你要添加的脚本,wander是定义的名称
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

  
    private void Awake()
    {
        
        enemys = GameObject.FindGameObjectsWithTag("ball");
        foreach (GameObject enemy in enemys)
        {
            wander = enemy.AddComponent<BALL>();//添加脚本
        }
    }

}
