﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class killball : MonoBehaviour
{
    int killnumber = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (killnumber>=10)
        {
            Debug.Log("Game Over");
            Time.timeScale = 0; //停滞游戏时间
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "ball")
        {
            Destroy(other.gameObject);
            killnumber++;
        }
    }
}
