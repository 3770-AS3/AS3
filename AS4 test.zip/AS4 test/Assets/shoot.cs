﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shoot : MonoBehaviour
{


    private float force = 500;
    private float leftorright;
    public Rigidbody shootBall;
    private float shootCD;
    public int n=5;
    // Use this for initialization
    void Start()
    {
        shootCD = 5;
    }

    // Update is called once per frame
    void Update()
    {
       
        shootCD -= Time.deltaTime;
        if (shootCD <= 0)
        {
            leftorright= Random.Range(500f, -500f);
            Rigidbody ball;
            ball = Instantiate(shootBall, this.transform.position, Quaternion.identity) as Rigidbody;
            ball.AddForce(force * ball.transform.forward);
            ball.AddForce(leftorright * ball.transform.right);
            shootCD = n;
            if (n > 1)
            {
                n--;
            }
        }
     


        
    }
}

  
