﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BALL : MonoBehaviour
{
    public GameObject sc;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnMouseDown()
    {
        Destroy(this.gameObject);
        sc.GetComponent<score>().add(1);
        Debug.Log(sc.GetComponent<score>().playerscore);

    }
}
